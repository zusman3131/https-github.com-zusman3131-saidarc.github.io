/**
 * Arc Raiders Guide - Premium JavaScript
 * Features: Theme Toggle, Animations, Mobile Nav, Filters
 */

(function() {
  'use strict';

  // ============================================
  // THEME MANAGEMENT
  // ============================================
  const ThemeManager = {
    key: 'arc-raiders-theme',
    
    init() {
      this.loadTheme();
      this.createToggleButton();
      this.listenForSystemChanges();
    },
    
    loadTheme() {
      const savedTheme = localStorage.getItem(this.key);
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const theme = savedTheme || (prefersDark ? 'dark' : 'light');
      this.applyTheme(theme);
    },
    
    applyTheme(theme) {
      document.documentElement.setAttribute('data-theme', theme);
      localStorage.setItem(this.key, theme);
      this.updateToggleIcon(theme);
    },
    
    toggle() {
      const currentTheme = document.documentElement.getAttribute('data-theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      this.applyTheme(newTheme);
    },
    
    updateToggleIcon(theme) {
      const toggle = document.querySelector('.theme-toggle');
      if (toggle) {
        toggle.setAttribute('aria-label', `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`);
      }
    },
    
    createToggleButton() {
      // Check if button already exists
      if (document.querySelector('.theme-toggle')) return;
      
      const button = document.createElement('button');
      button.className = 'theme-toggle';
      button.setAttribute('aria-label', 'Toggle theme');
      button.setAttribute('type', 'button');
      button.innerHTML = `
        <svg class="sun-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="5"/>
          <path stroke-linecap="round" d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
        </svg>
        <svg class="moon-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
          <path stroke-linecap="round" stroke-linejoin="round" d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>
        </svg>
      `;
      
      button.addEventListener('click', () => this.toggle());
      document.body.appendChild(button);
    },
    
    listenForSystemChanges() {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        if (!localStorage.getItem(this.key)) {
          this.applyTheme(e.matches ? 'dark' : 'light');
        }
      });
    }
  };

  // ============================================
  // ANIMATION OBSERVER
  // ============================================
  const AnimationObserver = {
    init() {
      const observerOptions = {
        root: null,
        rootMargin: '0px 0px -50px 0px',
        threshold: 0.1
      };
      
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
            observer.unobserve(entry.target);
          }
        });
      }, observerOptions);
      
      // Observe elements for animation
      const animatables = document.querySelectorAll(
        '.quickstart-card, .tip-card, .weapon-card, .map-card, .guide-item, .category-card, .mission-item'
      );
      
      animatables.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = `opacity 0.5s ease ${index * 0.05}s, transform 0.5s ease ${index * 0.05}s`;
        observer.observe(el);
      });
      
      // Add animate-in styles
      const style = document.createElement('style');
      style.textContent = `
        .animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
      `;
      document.head.appendChild(style);
    }
  };

  // ============================================
  // MOBILE NAVIGATION
  // ============================================
  const MobileNav = {
    init() {
      const navToggle = document.querySelector('.nav-toggle');
      const navMenu = document.querySelector('.nav-menu');
      
      if (!navToggle || !navMenu) return;
      
      navToggle.addEventListener('click', () => {
        const isOpen = navMenu.classList.toggle('active');
        navToggle.setAttribute('aria-expanded', isOpen);
        this.animateHamburger(navToggle, isOpen);
      });
      
      // Close menu when clicking links
      document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
          navMenu.classList.remove('active');
          navToggle.setAttribute('aria-expanded', 'false');
          this.animateHamburger(navToggle, false);
        });
      });
      
      // Close on escape key
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && navMenu.classList.contains('active')) {
          navMenu.classList.remove('active');
          navToggle.setAttribute('aria-expanded', 'false');
          this.animateHamburger(navToggle, false);
        }
      });
    },
    
    animateHamburger(toggle, isOpen) {
      const spans = toggle.querySelectorAll('span');
      if (isOpen) {
        spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
        spans[1].style.opacity = '0';
        spans[1].style.transform = 'translateX(-10px)';
        spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
      } else {
        spans[0].style.transform = 'none';
        spans[1].style.opacity = '1';
        spans[1].style.transform = 'none';
        spans[2].style.transform = 'none';
      }
    }
  };

  // ============================================
  // NAVBAR SCROLL EFFECTS
  // ============================================
  const NavbarScroll = {
    init() {
      const navbar = document.querySelector('.navbar');
      if (!navbar) return;
      
      let lastScroll = 0;
      let ticking = false;
      
      window.addEventListener('scroll', () => {
        if (!ticking) {
          window.requestAnimationFrame(() => {
            this.handleScroll(navbar, lastScroll);
            lastScroll = window.pageYOffset;
            ticking = false;
          });
          ticking = true;
        }
      }, { passive: true });
    },
    
    handleScroll(navbar, lastScroll) {
      const currentScroll = window.pageYOffset;
      
      // Add/remove background blur based on scroll
      if (currentScroll > 50) {
        navbar.style.background = 'rgba(10, 11, 15, 0.98)';
        navbar.style.backdropFilter = 'blur(20px)';
      } else {
        navbar.style.background = 'rgba(10, 11, 15, 0.9)';
        navbar.style.backdropFilter = 'blur(12px)';
      }
      
      // Hide/show on scroll direction (mobile only)
      if (window.innerWidth <= 768) {
        if (currentScroll > lastScroll && currentScroll > 100) {
          navbar.style.transform = 'translateY(-100%)';
        } else {
          navbar.style.transform = 'translateY(0)';
        }
      }
      
      lastScroll = currentScroll;
    }
  };

  // ============================================
  // SMOOTH SCROLL
  // ============================================
  const SmoothScroll = {
    init() {
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', (e) => {
          const targetId = anchor.getAttribute('href');
          if (targetId === '#') return;
          
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
            e.preventDefault();
            const navHeight = document.querySelector('.navbar')?.offsetHeight || 64;
            const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navHeight - 20;
            
            window.scrollTo({
              top: targetPosition,
              behavior: 'smooth'
            });
            
            // Update URL without jumping
            history.pushState(null, '', targetId);
          }
        });
      });
    }
  };

  // ============================================
  // WEAPON FILTERS
  // ============================================
  const WeaponFilters = {
    init() {
      const filterContainer = document.querySelector('.weapon-filters');
      if (!filterContainer) return;
      
      const categoryButtons = filterContainer.querySelectorAll('.filter-btn[data-category]');
      const rarityButtons = filterContainer.querySelectorAll('.filter-btn[data-rarity]');
      const searchInput = filterContainer.querySelector('.search-input');
      const weaponCards = document.querySelectorAll('.weapon-card');
      
      let activeCategory = 'all';
      let activeRarity = 'all';
      let searchTerm = '';
      
      // Category filter
      categoryButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          categoryButtons.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          activeCategory = btn.dataset.category;
          this.filterWeapons(weaponCards, activeCategory, activeRarity, searchTerm);
        });
      });
      
      // Rarity filter
      rarityButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          rarityButtons.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          activeRarity = btn.dataset.rarity;
          this.filterWeapons(weaponCards, activeCategory, activeRarity, searchTerm);
        });
      });
      
      // Search filter with debounce
      if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', () => {
          clearTimeout(debounceTimer);
          debounceTimer = setTimeout(() => {
            searchTerm = searchInput.value.toLowerCase();
            this.filterWeapons(weaponCards, activeCategory, activeRarity, searchTerm);
          }, 150);
        });
      }
    },
    
    filterWeapons(cards, category, rarity, search) {
      let visibleCount = 0;
      
      cards.forEach((card, index) => {
        const cardCategory = card.dataset.category;
        const cardRarity = card.dataset.rarity;
        const cardName = card.dataset.name || '';
        
        const matchesCategory = category === 'all' || cardCategory === category;
        const matchesRarity = rarity === 'all' || cardRarity === rarity;
        const matchesSearch = !search || cardName.includes(search);
        
        if (matchesCategory && matchesRarity && matchesSearch) {
          card.style.display = 'block';
          card.style.animation = `fade-in-up 0.4s ease ${index * 0.03}s both`;
          visibleCount++;
        } else {
          card.style.display = 'none';
        }
      });
      
      // Show/hide no results message
      let noResults = document.querySelector('.no-results');
      if (visibleCount === 0) {
        if (!noResults) {
          noResults = document.createElement('div');
          noResults.className = 'no-results';
          noResults.innerHTML = `
            <div style="text-align: center; padding: 4rem 2rem; color: var(--color-text-muted);">
              <div style="font-size: 3rem; margin-bottom: 1rem;">🔍</div>
              <h3 style="color: var(--color-text-primary); margin-bottom: 0.5rem;">No weapons found</h3>
              <p>Try adjusting your filters or search term</p>
            </div>
          `;
          document.querySelector('.weapons-grid')?.appendChild(noResults);
        }
        noResults.style.display = 'block';
      } else if (noResults) {
        noResults.style.display = 'none';
      }
    }
  };

  // ============================================
  // WEAPON COMPARISON
  // ============================================
  const WeaponComparison = {
    init() {
      const compareCheckboxes = document.querySelectorAll('.compare-checkbox');
      if (!compareCheckboxes.length) return;
      
      const compareBar = document.querySelector('.compare-bar');
      const compareList = document.querySelector('.compare-list');
      const compareBtn = document.querySelector('.btn-compare');
      const clearBtn = document.querySelector('.btn-clear-compare');
      
      let selectedWeapons = [];
      const maxCompare = 4;
      
      compareCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
          const weaponId = checkbox.dataset.weaponId;
          const weaponName = checkbox.dataset.weaponName;
          
          if (checkbox.checked) {
            if (selectedWeapons.length >= maxCompare) {
              checkbox.checked = false;
              Toast.show(`You can compare up to ${maxCompare} weapons`);
              return;
            }
            selectedWeapons.push({ id: weaponId, name: weaponName });
          } else {
            selectedWeapons = selectedWeapons.filter(w => w.id !== weaponId);
          }
          
          this.updateCompareBar(compareBar, compareList, selectedWeapons);
        });
      });
      
      if (clearBtn) {
        clearBtn.addEventListener('click', () => {
          selectedWeapons = [];
          compareCheckboxes.forEach(cb => cb.checked = false);
          this.updateCompareBar(compareBar, compareList, selectedWeapons);
        });
      }
      
      if (compareBtn) {
        compareBtn.addEventListener('click', () => {
          if (selectedWeapons.length < 2) {
            Toast.show('Select at least 2 weapons to compare');
            return;
          }
          const ids = selectedWeapons.map(w => w.id).join(',');
          window.location.href = `compare.html?weapons=${ids}`;
        });
      }
    },
    
    updateCompareBar(bar, list, weapons) {
      if (!bar) return;
      
      if (weapons.length > 0) {
        bar.classList.add('active');
        if (list) {
          list.innerHTML = weapons.map(w => 
            `<span class="compare-tag">${w.name}</span>`
          ).join('');
        }
      } else {
        bar.classList.remove('active');
      }
    }
  };

  // ============================================
  // TOAST NOTIFICATIONS
  // ============================================
  const Toast = {
    show(message, duration = 3000) {
      let toast = document.querySelector('.toast-notification');
      
      if (!toast) {
        toast = document.createElement('div');
        toast.className = 'toast-notification';
        document.body.appendChild(toast);
      }
      
      toast.textContent = message;
      toast.classList.add('show');
      
      // Clear existing timeout
      if (toast.timeoutId) {
        clearTimeout(toast.timeoutId);
      }
      
      toast.timeoutId = setTimeout(() => {
        toast.classList.remove('show');
      }, duration);
    }
  };

  // ============================================
  // STATS COUNTER ANIMATION
  // ============================================
  const StatsCounter = {
    init() {
      const statNumbers = document.querySelectorAll('.stat-number');
      
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            this.animateCounter(entry.target);
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.5 });
      
      statNumbers.forEach(stat => observer.observe(stat));
    },
    
    animateCounter(element) {
      const finalValue = element.textContent;
      const numericValue = parseInt(finalValue.replace(/\D/g, ''));
      const suffix = finalValue.replace(/[0-9]/g, '');
      
      if (isNaN(numericValue)) return;
      
      let currentValue = 0;
      const increment = numericValue / 30;
      const duration = 1000;
      const stepTime = duration / 30;
      
      const timer = setInterval(() => {
        currentValue += increment;
        if (currentValue >= numericValue) {
          element.textContent = finalValue;
          clearInterval(timer);
        } else {
          element.textContent = Math.floor(currentValue) + suffix;
        }
      }, stepTime);
    }
  };

  // ============================================
  // TABS FUNCTIONALITY
  // ============================================
  const Tabs = {
    init() {
      document.querySelectorAll('.tabs').forEach(group => {
        const tabs = group.querySelectorAll('.tab-btn');
        const panels = group.querySelectorAll('.tab-panel');
        
        tabs.forEach(tab => {
          tab.addEventListener('click', () => {
            const target = tab.dataset.tab;
            
            tabs.forEach(t => t.classList.remove('active'));
            panels.forEach(p => p.classList.remove('active'));
            
            tab.classList.add('active');
            group.querySelector(`[data-panel="${target}"]`)?.classList.add('active');
          });
        });
      });
    }
  };

  // ============================================
  // MAGNETIC BUTTONS (Desktop only)
  // ============================================
  const MagneticButtons = {
    init() {
      if (window.matchMedia('(pointer: coarse)').matches) return;
      
      document.querySelectorAll('.btn, .category-card, .quickstart-card').forEach(btn => {
        btn.addEventListener('mousemove', (e) => {
          const rect = btn.getBoundingClientRect();
          const x = e.clientX - rect.left - rect.width / 2;
          const y = e.clientY - rect.top - rect.height / 2;
          
          btn.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
        });
        
        btn.addEventListener('mouseleave', () => {
          btn.style.transform = '';
        });
      });
    }
  };

  // ============================================
  // INITIALIZE ALL MODULES
  // ============================================
  document.addEventListener('DOMContentLoaded', () => {
    ThemeManager.init();
    MobileNav.init();
    NavbarScroll.init();
    SmoothScroll.init();
    WeaponFilters.init();
    WeaponComparison.init();
    StatsCounter.init();
    Tabs.init();
    
    // Delay animations for better performance
    requestAnimationFrame(() => {
      AnimationObserver.init();
      MagneticButtons.init();
    });
  });

  // Expose Toast globally
  window.Toast = Toast;
  
})();
