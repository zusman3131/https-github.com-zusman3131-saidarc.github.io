/**
 * Arc Raiders - Crafting Calculator
 * Input materials and see what you can craft
 */

(function() {
    'use strict';

    // Recipe database
    const recipes = {
        weapons: [
            {
                name: 'Rattler Mk. I',
                tier: 'Mk. I',
                category: 'Assault Rifle',
                materials: { 'gun-receiver': 1, 'polymer-stock': 1, 'scrap': 50 }
            },
            {
                name: 'Rattler Mk. II',
                tier: 'Mk. II',
                category: 'Assault Rifle',
                materials: { 'rattler-mk1': 1, 'circuit-board': 1, 'heavy-mechanical': 2, 'scrap': 100 }
            },
            {
                name: 'Ferro Mk. I',
                tier: 'Mk. I',
                category: 'Battle Rifle',
                materials: { 'heavy-receiver': 1, 'reinforced-stock': 1, 'scrap': 60 }
            },
            {
                name: 'Ferro Mk. II',
                tier: 'Mk. II',
                category: 'Battle Rifle',
                materials: { 'ferro-mk1': 1, 'power-unit': 1, 'steel-parts': 2, 'scrap': 120 }
            },
            {
                name: 'Tempest',
                tier: 'Base',
                category: 'Assault Rifle',
                materials: { 'crafting-level': 1 },
                note: 'Unlocked at Crafting Table Level 1'
            },
            {
                name: 'Tempest Mk. II',
                tier: 'Mk. II',
                category: 'Assault Rifle',
                materials: { 'tempest': 1, 'advanced-circuit': 1, 'precision-parts': 2, 'scrap': 150 }
            },
            {
                name: 'Renegade',
                tier: 'Base',
                category: 'Battle Rifle',
                materials: { 'crafting-level': 1 },
                note: 'Unlocked at Crafting Table Level 1'
            },
            {
                name: 'Renegade Mk. II',
                tier: 'Mk. II',
                category: 'Battle Rifle',
                materials: { 'renegade': 1, 'power-unit': 1, 'precision-parts': 2, 'scrap': 150 }
            },
            {
                name: 'Bettina Mk. I',
                tier: 'Mk. I',
                category: 'Assault Rifle',
                materials: { 'advanced-receiver': 1, 'heavy-barrel': 1, 'polymer-grip': 1, 'scrap': 100 }
            },
            {
                name: 'Osprey Mk. I',
                tier: 'Mk. I',
                category: 'Sniper Rifle',
                materials: { 'precision-receiver': 1, 'long-barrel': 1, 'sniper-stock': 1, 'scrap': 120 }
            }
        ],
        equipment: [
            {
                name: 'Looting Mk. 2 Backpack',
                tier: 'Level 1',
                category: 'Backpack',
                materials: { 'backpack-frame': 1, 'reinforced-fabric': 3, 'mechanical-parts': 2, 'scrap': 80 },
                priority: 'high',
                note: '⭐ PRIORITY - Two safe pocket slots!'
            },
            {
                name: 'Tactical Mk. 1 Backpack',
                tier: 'Level 1',
                category: 'Backpack',
                materials: { 'backpack-frame': 1, 'ballistic-fiber': 2, 'mechanical-parts': 3, 'scrap': 100 }
            },
            {
                name: 'Frag Grenade',
                tier: 'Level 0',
                category: 'Grenade',
                materials: { 'metal-casing': 1, 'explosive-compound': 1, 'wire': 1, 'scrap': 20 }
            },
            {
                name: 'Smoke Grenade',
                tier: 'Level 0',
                category: 'Grenade',
                materials: { 'metal-casing': 1, 'chemical-agents': 2, 'wire': 1, 'scrap': 20 }
            },
            {
                name: 'Flashbang',
                tier: 'Level 1',
                category: 'Grenade',
                materials: { 'metal-casing': 1, 'flash-powder': 1, 'electronic-component': 1, 'scrap': 30 }
            },
            {
                name: 'Bandage',
                tier: 'Level 0',
                category: 'Healing',
                materials: { 'cloth': 1, 'antiseptic': 1, 'scrap': 10 }
            },
            {
                name: 'Medkit',
                tier: 'Level 1',
                category: 'Healing',
                materials: { 'cloth': 2, 'antiseptic': 2, 'stimulant': 1, 'scrap': 40 }
            },
            {
                name: 'Combat Stim',
                tier: 'Level 2',
                category: 'Healing',
                materials: { 'stimulant': 2, 'advanced-chemicals': 1, 'electronic-component': 1, 'scrap': 60 }
            }
        ]
    };

    // Material display names
    const materialNames = {
        'scrap': 'Scrap',
        'gun-receiver': 'Gun Receiver',
        'polymer-stock': 'Polymer Stock',
        'circuit-board': 'Circuit Board',
        'heavy-mechanical': 'Heavy Mechanical Parts',
        'heavy-receiver': 'Heavy Gun Receiver',
        'reinforced-stock': 'Reinforced Stock',
        'power-unit': 'Power Unit',
        'steel-parts': 'Steel Parts',
        'advanced-circuit': 'Advanced Circuit',
        'precision-parts': 'Precision Parts',
        'advanced-receiver': 'Advanced Receiver',
        'heavy-barrel': 'Heavy Barrel',
        'polymer-grip': 'Polymer Grip',
        'precision-receiver': 'Precision Receiver',
        'long-barrel': 'Long Barrel',
        'sniper-stock': 'Sniper Stock',
        'backpack-frame': 'Backpack Frame',
        'reinforced-fabric': 'Reinforced Fabric',
        'mechanical-parts': 'Mechanical Parts',
        'ballistic-fiber': 'Ballistic Fiber',
        'metal-casing': 'Metal Casing',
        'explosive-compound': 'Explosive Compound',
        'wire': 'Wire',
        'chemical-agents': 'Chemical Agents',
        'flash-powder': 'Flash Powder',
        'electronic-component': 'Electronic Component',
        'cloth': 'Cloth',
        'antiseptic': 'Antiseptic',
        'stimulant': 'Stimulant',
        'advanced-chemicals': 'Advanced Chemicals',
        'rattler-mk1': 'Rattler Mk. I',
        'ferro-mk1': 'Ferro Mk. I',
        'tempest': 'Tempest',
        'renegade': 'Renegade',
        'crafting-level': 'Crafting Table Level'
    };

    function init() {
        createCalculatorUI();
    }

    // Create calculator UI
    function createCalculatorUI() {
        const craftingSection = document.querySelector('.section-dark .container');
        if (!craftingSection) return;

        // Check if we're on the crafting page
        if (!window.location.href.includes('crafting.html')) return;

        const calculator = document.createElement('div');
        calculator.className = 'crafting-calculator';
        calculator.innerHTML = `
            <div class="calculator-header">
                <h2 class="section-title">🧮 Crafting Calculator</h2>
                <p class="section-subtitle">Enter your materials to see what you can craft</p>
            </div>
            
            <div class="calculator-body">
                <div class="materials-input">
                    <h4>Your Materials</h4>
                    <div class="material-grid">
                        ${generateMaterialInputs()}
                    </div>
                    <div class="calculator-actions">
                        <button class="btn btn-primary btn-calculate">Calculate</button>
                        <button class="btn btn-secondary btn-reset">Reset</button>
                    </div>
                </div>
                
                <div class="craftable-results">
                    <h4>What You Can Craft</h4>
                    <div class="results-content">
                        <div class="results-placeholder">
                            <span>📋</span>
                            <p>Enter your materials and click Calculate</p>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Insert after the crafting intro
        const craftingIntro = craftingSection.querySelector('.crafting-intro');
        if (craftingIntro) {
            craftingIntro.after(calculator);
        } else {
            craftingSection.insertBefore(calculator, craftingSection.firstChild);
        }

        // Event listeners
        calculator.querySelector('.btn-calculate').addEventListener('click', calculateCraftables);
        calculator.querySelector('.btn-reset').addEventListener('click', resetCalculator);
        
        // Quick add buttons
        calculator.querySelectorAll('.quick-add').forEach(btn => {
            btn.addEventListener('click', function() {
                const input = this.parentElement.querySelector('input');
                const current = parseInt(input.value) || 0;
                const add = parseInt(this.dataset.add);
                input.value = current + add;
            });
        });
    }

    // Generate material input fields
    function generateMaterialInputs() {
        const commonMaterials = [
            ['scrap', 'Scrap', 999],
            ['mechanical-parts', 'Mechanical Parts', 20],
            ['electronic-component', 'Electronic Components', 10],
            ['circuit-board', 'Circuit Boards', 10],
            ['gun-receiver', 'Gun Receivers', 5],
            ['polymer-stock', 'Polymer Stocks', 5],
            ['power-unit', 'Power Units', 5],
            ['backpack-frame', 'Backpack Frames', 3],
            ['reinforced-fabric', 'Reinforced Fabric', 10],
            ['cloth', 'Cloth', 20],
            ['antiseptic', 'Antiseptic', 10],
            ['stimulant', 'Stimulants', 5]
        ];

        return commonMaterials.map(([id, name, max]) => `
            <div class="material-input-item">
                <label for="mat-${id}">${name}</label>
                <div class="input-with-quick">
                    <input type="number" id="mat-${id}" data-material="${id}" min="0" max="${max}" placeholder="0">
                    <div class="quick-adds">
                        <button class="quick-add" data-add="1">+1</button>
                        <button class="quick-add" data-add="5">+5</button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // Calculate what can be crafted
    function calculateCraftables() {
        // Get all material inputs
        const inputs = document.querySelectorAll('.material-grid input');
        const inventory = {};
        
        inputs.forEach(input => {
            const value = parseInt(input.value) || 0;
            if (value > 0) {
                inventory[input.dataset.material] = value;
            }
        });

        // Check each recipe
        const craftable = [];
        const needMore = [];

        [...recipes.weapons, ...recipes.equipment].forEach(recipe => {
            const status = checkRecipe(recipe, inventory);
            if (status.canCraft) {
                craftable.push({ ...recipe, missing: status.missing });
            } else if (status.missing.length > 0 && status.missing.length <= 2) {
                needMore.push({ ...recipe, missing: status.missing });
            }
        });

        // Sort: priority items first, then by name
        craftable.sort((a, b) => {
            if (a.priority === 'high') return -1;
            if (b.priority === 'high') return 1;
            return a.name.localeCompare(b.name);
        });

        displayResults(craftable, needMore);
    }

    // Check if a recipe can be crafted
    function checkRecipe(recipe, inventory) {
        const missing = [];
        let canCraft = true;

        for (const [material, amount] of Object.entries(recipe.materials)) {
            if (material === 'crafting-level') continue;
            
            const have = inventory[material] || 0;
            if (have < amount) {
                canCraft = false;
                missing.push({
                    material,
                    need: amount,
                    have
                });
            }
        }

        return { canCraft, missing };
    }

    // Display results
    function displayResults(craftable, needMore) {
        const resultsContent = document.querySelector('.results-content');
        
        if (craftable.length === 0 && needMore.length === 0) {
            resultsContent.innerHTML = `
                <div class="results-placeholder">
                    <span>❌</span>
                    <p>You don't have enough materials to craft anything yet.</p>
                    <small>Enter more materials or check the recipe requirements</small>
                </div>
            `;
            return;
        }

        let html = '';

        if (craftable.length > 0) {
            html += `
                <div class="results-section">
                    <h5 class="results-title can-craft">✅ Can Craft (${craftable.length})</h5>
                    <div class="recipe-list">
                        ${craftable.map(r => `
                            <div class="recipe-item ${r.priority || ''}">
                                <div class="recipe-info">
                                    <span class="recipe-name">${r.name}</span>
                                    <span class="recipe-meta">${r.category} • ${r.tier}</span>
                                    ${r.note ? `<span class="recipe-note">${r.note}</span>` : ''}
                                </div>
                                <div class="recipe-materials-mini">
                                    ${Object.entries(r.materials).filter(([m]) => m !== 'crafting-level').map(([m, amt]) => `
                                        <span class="mini-mat">${amt}× ${materialNames[m] || m}</span>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        if (needMore.length > 0) {
            html += `
                <div class="results-section">
                    <h5 class="results-title need-more">⚠️ Need More Materials (${needMore.length})</h5>
                    <div class="recipe-list">
                        ${needMore.slice(0, 5).map(r => `
                            <div class="recipe-item partial">
                                <div class="recipe-info">
                                    <span class="recipe-name">${r.name}</span>
                                    <span class="recipe-meta">${r.category} • ${r.tier}</span>
                                </div>
                                <div class="missing-list">
                                    ${r.missing.map(m => `
                                        <span class="missing-item">
                                            Need ${m.need - m.have} more ${materialNames[m.material] || m.material}
                                        </span>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')}
                        ${needMore.length > 5 ? `<p class="more-items">...and ${needMore.length - 5} more</p>` : ''}
                    </div>
                </div>
            `;
        }

        resultsContent.innerHTML = html;
    }

    // Reset calculator
    function resetCalculator() {
        document.querySelectorAll('.material-grid input').forEach(input => {
            input.value = '';
        });
        document.querySelector('.results-content').innerHTML = `
            <div class="results-placeholder">
                <span>📋</span>
                <p>Enter your materials and click Calculate</p>
            </div>
        `;
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
