/**
 * Arc Raiders - Map Interactive Hotspots
 * Clickable POI indicators with detailed information
 */

(function() {
    'use strict';

    // Map data with hotspots
    const mapData = {
        'dam': {
            name: 'Dam Battlegrounds',
            hotspots: [
                { id: 'dam-control-tower', name: 'Control Tower', type: 'loot', x: 65, y: 25, 
                  info: 'High loot area with fewer ambush points on upper floors. Great for gun parts and blueprints.' },
                { id: 'dam-research', name: 'Research & Admin', type: 'loot', x: 70, y: 30,
                  info: 'Excellent loot standing side-by-side with Control Tower. Security lockers common.' },
                { id: 'dam-hydroponic', name: 'Hydroponic Dome', type: 'arc', x: 45, y: 40,
                  info: 'Nature and Security loot, plenty of ARC patrols. Great for farming ARC materials.' },
                { id: 'dam-power', name: 'Power Generation', type: 'extract', x: 30, y: 60,
                  info: 'Solid loot with extraction point nearby. Good for quick raids.' },
                { id: 'dam-testing', name: 'Testing Annex', type: 'loot', x: 55, y: 55,
                  info: 'Mid-tier loot, good for beginners learning the map.' },
                { id: 'dam-water', name: 'Water Treatment', type: 'loot', x: 40, y: 70,
                  info: 'Components for early crafting. Low enemy density.' },
                { id: 'dam-north-extract', name: 'North Extract', type: 'extract', x: 50, y: 10,
                  info: 'Primary extraction point. Watch for campers during peak hours.' },
                { id: 'dam-south-extract', name: 'South Extract', type: 'extract', x: 50, y: 90,
                  info: 'Secondary extraction. Usually less contested than North.' }
            ]
        },
        'buried-city': {
            name: 'Buried City',
            hotspots: [
                { id: 'bc-piazza-roma', name: 'Piazza Roma', type: 'loot', x: 50, y: 35,
                  info: 'Loot-rich plaza with multiple buildings. High PvP area.' },
                { id: 'bc-piazza-arbusto', name: 'Piazza Arbusto', type: 'loot', x: 35, y: 45,
                  info: 'Accessories and unique items in breachable buildings.' },
                { id: 'bc-hospital', name: 'Hospital', type: 'pvp', x: 60, y: 40,
                  info: 'Great loot but often camped by players. Bring a team.' },
                { id: 'bc-town-hall', name: 'Town Hall', type: 'loot', x: 50, y: 50,
                  info: 'Central location with multi-level combat.' },
                { id: 'bc-red-tower', name: 'Red Tower', type: 'loot', x: 70, y: 30,
                  info: 'Corners have security lockers. Good for blueprints.' },
                { id: 'bc-marano', name: 'Marano Station', type: 'extract', x: 25, y: 75,
                  info: 'Underground extraction. Stash loop is fast and lucrative.' },
                { id: 'bc-east-exit', name: 'East Exit', type: 'extract', x: 85, y: 50,
                  info: 'Open area extraction. Use smoke for cover.' }
            ]
        },
        'spaceport': {
            name: 'Spaceport',
            hotspots: [
                { id: 'sp-launch-tower', name: 'Launch Tower', type: 'loot', x: 50, y: 20,
                  info: 'Highest loot potential in the game. Bring your best gear and expect PvP.' },
                { id: 'sp-containers', name: 'Container Storage', type: 'pvp', x: 75, y: 35,
                  info: 'Excellent crates but fierce competition. Popular landing spot.' },
                { id: 'sp-departure', name: 'Departure Building', type: 'loot', x: 30, y: 40,
                  info: 'Lockers with great loot, especially at night. Bring NVGs.' },
                { id: 'sp-control-a6', name: 'Control Tower A6', type: 'loot', x: 65, y: 45,
                  info: 'Security lockers on west side. Good for tech modules.' },
                { id: 'sp-fuel-lines', name: 'Fuel Lines', type: 'loot', x: 20, y: 60,
                  info: 'Zipline access to rooftop crates. Quick in-and-out.' },
                { id: 'sp-medical', name: 'Medical Area', type: 'loot', x: 40, y: 70,
                  info: 'Safes and large amount of loot. Medical supplies guaranteed.' },
                { id: 'sp-north-tower', name: 'North Tower Extract', type: 'extract', x: 50, y: 5,
                  info: 'High ground extraction. Good visibility for spotting enemies.' },
                { id: 'sp-south-tower', name: 'South Tower Extract', type: 'extract', x: 50, y: 95,
                  info: 'Lower elevation but well covered.' }
            ]
        },
        'blue-gate': {
            name: 'The Blue Gate',
            hotspots: [
                { id: 'bg-refuge', name: "Raider's Refuge", type: 'loot', x: 20, y: 80,
                  info: 'Southwest corner, good starting point for new squads.' },
                { id: 'bg-bunker', name: 'Maintenance Bunker', type: 'loot', x: 45, y: 60,
                  info: 'Underground corridor with loot. Safe passage option.' },
                { id: 'bg-reception', name: 'Reinforced Reception', type: 'loot', x: 60, y: 35,
                  info: 'Zipline down to security lockers. High-tier loot.' },
                { id: 'bg-peak', name: "Pilgrimage's Peak", type: 'arc', x: 80, y: 20,
                  info: 'Northeast corner POI. Heavy ARC presence.' },
                { id: 'bg-village', name: 'The Village', type: 'loot', x: 15, y: 25,
                  info: 'Top-left buildings have key spawns. Check every drawer.' },
                { id: 'bg-container', name: 'Container Storage', type: 'loot', x: 70, y: 70,
                  info: 'Top floor requires Spaceport key. Worth the trip.' },
                { id: 'bg-hatch-north', name: 'Raider Hatch North', type: 'extract', x: 50, y: 10,
                  info: 'Requires key but provides safest extraction on the map.' },
                { id: 'bg-hatch-south', name: 'Raider Hatch South', type: 'extract', x: 50, y: 90,
                  info: 'Alternative hatch exit. Usually less guarded.' }
            ]
        }
    };

    // Type icons and colors
    const typeConfig = {
        loot: { icon: '💰', color: '#fbbf24', label: 'Loot' },
        extract: { icon: '🏃', color: '#4ade80', label: 'Extract' },
        pvp: { icon: '⚔️', color: '#ef4444', label: 'PvP Zone' },
        arc: { icon: '🤖', color: '#a78bfa', label: 'ARC Zone' }
    };

    function init() {
        createMapInteractiveElements();
        createMapSelector();
        createHotspotModal();
    }

    // Create interactive map elements
    function createMapInteractiveElements() {
        const mapCards = document.querySelectorAll('.map-detail-card');
        
        mapCards.forEach(card => {
            const mapId = card.id;
            const mapInfo = mapData[mapId];
            
            if (!mapInfo) return;

            // Create map visual container
            const mapVisual = document.createElement('div');
            mapVisual.className = 'interactive-map';
            mapVisual.innerHTML = `
                <div class="map-canvas" data-map-id="${mapId}">
                    <div class="map-placeholder">
                        <span class="map-icon">🗺️</span>
                        <span class="map-text">${mapInfo.name}</span>
                        <span class="map-hint">Click points for details</span>
                    </div>
                    ${mapInfo.hotspots.map(hotspot => `
                        <button class="map-hotspot ${hotspot.type}" 
                                style="left: ${hotspot.x}%; top: ${hotspot.y}%;"
                                data-hotspot-id="${hotspot.id}"
                                data-map-id="${mapId}"
                                title="${hotspot.name}">
                            <span class="hotspot-icon">${typeConfig[hotspot.type].icon}</span>
                            <span class="hotspot-pulse"></span>
                        </button>
                    `).join('')}
                </div>
                <div class="map-legend">
                    ${Object.entries(typeConfig).map(([key, config]) => `
                        <div class="legend-item">
                            <span class="legend-dot" style="background: ${config.color}"></span>
                            <span class="legend-label">${config.label}</span>
                        </div>
                    `).join('')}
                </div>
            `;

            // Insert at the beginning of map body
            const mapBody = card.querySelector('.map-detail-body');
            if (mapBody) {
                mapBody.insertBefore(mapVisual, mapBody.firstChild);
            }

            // Add click handlers
            mapVisual.querySelectorAll('.map-hotspot').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const hotspotId = this.dataset.hotspotId;
                    const mapId = this.dataset.mapId;
                    showHotspotDetails(mapId, hotspotId);
                });
            });
        });
    }

    // Create map selector for quick navigation
    function createMapSelector() {
        const mapsSection = document.querySelector('.maps-overview');
        if (!mapsSection) return;

        const selector = document.createElement('div');
        selector.className = 'map-selector';
        selector.innerHTML = `
            <h3>Quick Navigation</h3>
            <div class="map-selector-buttons">
                ${Object.entries(mapData).map(([id, data]) => `
                    <a href="#${id}" class="map-selector-btn" data-target="${id}">
                        <span class="selector-icon">🗺️</span>
                        <span class="selector-name">${data.name}</span>
                    </a>
                `).join('')}
            </div>
        `;

        mapsSection.parentNode.insertBefore(selector, mapsSection);

        // Smooth scroll for selector buttons
        selector.querySelectorAll('.map-selector-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                const targetId = this.dataset.target;
                const target = document.getElementById(targetId);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });
    }

    // Create hotspot detail modal
    function createHotspotModal() {
        const modal = document.createElement('div');
        modal.className = 'hotspot-modal';
        modal.id = 'hotspot-modal';
        modal.innerHTML = `
            <div class="hotspot-modal-overlay"></div>
            <div class="hotspot-modal-content">
                <button class="modal-close">&times;</button>
                <div class="hotspot-header">
                    <span class="hotspot-type-icon"></span>
                    <h3 class="hotspot-name"></h3>
                    <span class="hotspot-type-label"></span>
                </div>
                <div class="hotspot-info">
                    <p class="hotspot-description"></p>
                </div>
                <div class="hotspot-actions">
                    <button class="btn btn-small btn-prev">← Previous</button>
                    <button class="btn btn-small btn-next">Next →</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Close handlers
        modal.querySelector('.modal-close').addEventListener('click', hideHotspotModal);
        modal.querySelector('.hotspot-modal-overlay').addEventListener('click', hideHotspotModal);

        // Navigation
        modal.querySelector('.btn-prev').addEventListener('click', () => navigateHotspot(-1));
        modal.querySelector('.btn-next').addEventListener('click', () => navigateHotspot(1));
    }

    let currentMapId = null;
    let currentHotspotIndex = 0;

    // Show hotspot details
    function showHotspotDetails(mapId, hotspotId) {
        const map = mapData[mapId];
        if (!map) return;

        const index = map.hotspots.findIndex(h => h.id === hotspotId);
        if (index === -1) return;

        currentMapId = mapId;
        currentHotspotIndex = index;

        updateHotspotModal();

        const modal = document.getElementById('hotspot-modal');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    // Update modal content
    function updateHotspotModal() {
        const map = mapData[currentMapId];
        const hotspot = map.hotspots[currentHotspotIndex];
        const typeInfo = typeConfig[hotspot.type];

        const modal = document.getElementById('hotspot-modal');
        modal.querySelector('.hotspot-type-icon').textContent = typeInfo.icon;
        modal.querySelector('.hotspot-type-icon').style.background = typeInfo.color;
        modal.querySelector('.hotspot-name').textContent = hotspot.name;
        modal.querySelector('.hotspot-type-label').textContent = typeInfo.label;
        modal.querySelector('.hotspot-type-label').style.color = typeInfo.color;
        modal.querySelector('.hotspot-description').textContent = hotspot.info;

        // Update nav buttons
        modal.querySelector('.btn-prev').disabled = currentHotspotIndex === 0;
        modal.querySelector('.btn-next').disabled = currentHotspotIndex === map.hotspots.length - 1;
    }

    // Navigate between hotspots
    function navigateHotspot(direction) {
        const map = mapData[currentMapId];
        const newIndex = currentHotspotIndex + direction;

        if (newIndex >= 0 && newIndex < map.hotspots.length) {
            currentHotspotIndex = newIndex;
            updateHotspotModal();
        }
    }

    // Hide hotspot modal
    function hideHotspotModal() {
        const modal = document.getElementById('hotspot-modal');
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
