/**
 * Arc Raiders - Weapon Comparison Tool
 * Allows users to select and compare 2-4 weapons side-by-side
 */

(function() {
    'use strict';

    // Weapon database with complete stats
    const weaponDatabase = {
        'kettle': {
            name: 'Kettle',
            category: 'Assault Rifle',
            rarity: 'common',
            damage: 10,
            fireRate: 28,
            range: 42.8,
            ammo: 'Light',
            magazine: 20,
            mode: 'Semi-Auto',
            penetration: 'Very Weak',
            description: 'Quick and accurate, but has low bullet velocity and takes a long time to reload.'
        },
        'rattler': {
            name: 'Rattler',
            category: 'Assault Rifle',
            rarity: 'common',
            damage: 9,
            fireRate: 33.3,
            range: 56.2,
            ammo: 'Medium',
            magazine: 10,
            mode: 'Full-Auto',
            penetration: 'Moderate',
            description: 'An affordable offensive option, but must be reloaded 2 bullets at a time.'
        },
        'arpeggio': {
            name: 'Arpeggio',
            category: 'Assault Rifle',
            rarity: 'uncommon',
            damage: 9.5,
            fireRate: 18.3,
            range: 55.9,
            ammo: 'Medium',
            magazine: 24,
            mode: '3-Round Burst',
            penetration: 'Moderate',
            description: 'A 3-round burst assault rifle with decent damage output and accuracy.'
        },
        'tempest': {
            name: 'Tempest',
            category: 'Assault Rifle',
            rarity: 'epic',
            damage: 10,
            fireRate: 36.7,
            range: 55.9,
            ammo: 'Medium',
            magazine: 25,
            mode: 'Full-Auto',
            penetration: 'Moderate',
            description: 'Fully automatic assault rifle with moderate fire rate and accuracy.'
        },
        'bettina': {
            name: 'Bettina',
            category: 'Assault Rifle',
            rarity: 'epic',
            damage: 14,
            fireRate: 32,
            range: 51.3,
            ammo: 'Heavy',
            magazine: 20,
            mode: 'Full-Auto',
            penetration: 'Strong',
            description: 'Has slow fire rate and high damage output. Heavy ammo consumption is the trade-off.'
        },
        'ferro': {
            name: 'Ferro',
            category: 'Battle Rifle',
            rarity: 'common',
            damage: 40,
            fireRate: 6.6,
            range: 53.1,
            ammo: 'Heavy',
            magazine: 1,
            mode: 'Break-Action',
            penetration: 'Strong',
            description: 'Packs a punch, but must be reloaded between every shot. Excellent ARC armor penetration.'
        },
        'renegade': {
            name: 'Renegade',
            category: 'Battle Rifle',
            rarity: 'rare',
            damage: 35,
            fireRate: 21,
            range: 68.8,
            ammo: 'Medium',
            magazine: 8,
            mode: 'Lever-Action',
            penetration: 'Moderate',
            description: 'Has high damage output, accuracy and headshot damage. Excellent for mid-to-long range.'
        },
        'aphelion': {
            name: 'Aphelion',
            category: 'Battle Rifle',
            rarity: 'legendary',
            damage: 25,
            fireRate: 9,
            range: 76,
            ammo: 'Energy',
            magazine: 10,
            mode: '2-Round Burst',
            penetration: 'Strong',
            description: 'Fires high velocity energy rounds. Experimental weapon with high rarity cost.'
        },
        'stitcher': {
            name: 'Stitcher',
            category: 'SMG',
            rarity: 'common',
            damage: 7,
            fireRate: 45.3,
            range: 42.1,
            ammo: 'Light',
            magazine: 20,
            mode: 'Full-Auto',
            penetration: 'Very Weak',
            description: 'Your starting SMG. Deals good damage but has low fire-rate and can be hard to control.'
        },
        'bobcat': {
            name: 'Bobcat',
            category: 'SMG',
            rarity: 'epic',
            damage: 6,
            fireRate: 66.7,
            range: 44,
            ammo: 'Light',
            magazine: 20,
            mode: 'Full-Auto',
            penetration: 'Very Weak',
            description: 'Has high fire rate but low accuracy. Shreds heavily armored opponents at close range.'
        },
        'il-toro': {
            name: 'Il Toro',
            category: 'Shotgun',
            rarity: 'uncommon',
            damage: 67.5,
            fireRate: 14.3,
            range: 20,
            ammo: 'Shotgun',
            magazine: 5,
            mode: 'Pump-Action',
            penetration: 'Weak',
            description: 'Has large bullet spread, sharp falloff, and high damage output. 2-3 shots to kill.'
        },
        'vulcano': {
            name: 'Vulcano',
            category: 'Shotgun',
            rarity: 'epic',
            damage: 49.5,
            fireRate: 26.4,
            range: 22.2,
            ammo: 'Shotgun',
            magazine: 6,
            mode: 'Semi-Auto',
            penetration: 'Weak',
            description: 'Deals highest per-shot damage. Fast firing speed but only 4 shots before reloading.'
        },
        'osprey': {
            name: 'Osprey',
            category: 'Sniper Rifle',
            rarity: 'rare',
            damage: 45,
            fireRate: 17.6,
            range: 80,
            ammo: 'Medium',
            magazine: 8,
            mode: 'Bolt-Action',
            penetration: 'Moderate',
            description: 'Pre-equipped with long-range scope. Harder to use at close range due to permanent scope.'
        },
        'jupiter': {
            name: 'Jupiter',
            category: 'Sniper Rifle',
            rarity: 'legendary',
            damage: 60,
            fireRate: 12,
            range: 78.2,
            ammo: 'Energy',
            magazine: 5,
            mode: 'Bolt-Action',
            penetration: 'Very Strong',
            description: 'Endgame sniper with incredible velocity. Capable of damaging multiple targets with one shot.'
        },
        'torrente': {
            name: 'Torrente',
            category: 'LMG',
            rarity: 'rare',
            damage: 8,
            fireRate: 58.3,
            range: 49.9,
            ammo: 'Medium',
            magazine: 60,
            mode: 'Full-Auto',
            penetration: 'Moderate',
            description: 'Large ammo capacity, but only accurate while crouched. Highest DPS full-auto weapon.'
        },
        'equalizer': {
            name: 'Equalizer',
            category: 'Special',
            rarity: 'legendary',
            damage: 8,
            fireRate: 33.5,
            range: 68.2,
            ammo: 'Energy',
            magazine: 50,
            mode: 'Beam',
            penetration: 'Very Strong',
            description: 'High capacity experimental beam rifle. Extremely effective against ARC armor and limbs.'
        },
        'hullcracker': {
            name: 'Hullcracker',
            category: 'Special',
            rarity: 'epic',
            damage: 100,
            fireRate: 20.3,
            range: 38.9,
            ammo: 'Launcher',
            magazine: 5,
            mode: 'Pump-Action',
            penetration: 'Very Strong',
            description: 'Fires explosive projectiles that ONLY detonate on ARC. Use against Bastions and Queens.'
        }
    };

    // State
    let selectedWeapons = [];
    let compareModal = null;

    // Initialize
    function init() {
        createCompareUI();
        addCompareButtons();
        createModal();
    }

    // Create comparison UI elements
    function createCompareUI() {
        const weaponsSection = document.querySelector('.weapons-section .container');
        if (!weaponsSection) return;

        // Create compare bar
        const compareBar = document.createElement('div');
        compareBar.className = 'compare-bar';
        compareBar.innerHTML = `
            <div class="compare-bar-content">
                <span class="compare-label">Compare Weapons:</span>
                <div class="compare-list"></div>
                <div class="compare-actions">
                    <button class="btn btn-small btn-clear-compare" style="display: none;">Clear</button>
                    <button class="btn btn-small btn-compare" disabled>Compare (0)</button>
                </div>
            </div>
        `;

        // Insert before weapons grid
        const weaponsGrid = weaponsSection.querySelector('.weapons-grid');
        if (weaponsGrid) {
            weaponsSection.insertBefore(compareBar, weaponsGrid);
        }

        // Event listeners
        const clearBtn = compareBar.querySelector('.btn-clear-compare');
        const compareBtn = compareBar.querySelector('.btn-compare');

        clearBtn.addEventListener('click', clearSelection);
        compareBtn.addEventListener('click', showComparison);
    }

    // Add compare buttons to each weapon card
    function addCompareButtons() {
        const weaponCards = document.querySelectorAll('.weapon-card');
        
        weaponCards.forEach(card => {
            const weaponId = card.dataset.name;
            const weaponName = card.querySelector('.weapon-name').textContent;
            
            // Create compare checkbox
            const compareWrapper = document.createElement('label');
            compareWrapper.className = 'compare-checkbox-wrapper';
            compareWrapper.innerHTML = `
                <input type="checkbox" class="compare-checkbox" data-weapon-id="${weaponId}" data-weapon-name="${weaponName}">
                <span class="compare-label-text">Compare</span>
            `;

            // Add to weapon header
            const header = card.querySelector('.weapon-header');
            if (header) {
                header.appendChild(compareWrapper);
            }

            // Event listener
            const checkbox = compareWrapper.querySelector('.compare-checkbox');
            checkbox.addEventListener('change', function() {
                handleWeaponSelect(weaponId, weaponName, this.checked);
            });
        });
    }

    // Handle weapon selection
    function handleWeaponSelect(weaponId, weaponName, isSelected) {
        if (isSelected) {
            if (selectedWeapons.length >= 4) {
                showToast('You can compare up to 4 weapons');
                // Uncheck the checkbox
                const checkbox = document.querySelector(`.compare-checkbox[data-weapon-id="${weaponId}"]`);
                if (checkbox) checkbox.checked = false;
                return;
            }
            selectedWeapons.push({ id: weaponId, name: weaponName });
        } else {
            selectedWeapons = selectedWeapons.filter(w => w.id !== weaponId);
        }

        updateCompareBar();
    }

    // Update compare bar UI
    function updateCompareBar() {
        const compareBar = document.querySelector('.compare-bar');
        if (!compareBar) return;

        const compareList = compareBar.querySelector('.compare-list');
        const compareBtn = compareBar.querySelector('.btn-compare');
        const clearBtn = compareBar.querySelector('.btn-clear-compare');

        if (selectedWeapons.length > 0) {
            compareBar.classList.add('active');
            compareList.innerHTML = selectedWeapons.map(w => 
                `<span class="compare-tag" data-id="${w.id}">${w.name} <button class="remove-tag" data-id="${w.id}">×</button></span>`
            ).join('');
            
            compareBtn.disabled = selectedWeapons.length < 2;
            compareBtn.textContent = `Compare (${selectedWeapons.length})`;
            clearBtn.style.display = 'inline-block';

            // Add remove listeners
            compareList.querySelectorAll('.remove-tag').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const id = this.dataset.id;
                    const checkbox = document.querySelector(`.compare-checkbox[data-weapon-id="${id}"]`);
                    if (checkbox) checkbox.checked = false;
                    handleWeaponSelect(id, '', false);
                });
            });
        } else {
            compareBar.classList.remove('active');
            compareList.innerHTML = '';
            compareBtn.disabled = true;
            compareBtn.textContent = 'Compare (0)';
            clearBtn.style.display = 'none';
        }
    }

    // Clear all selections
    function clearSelection() {
        selectedWeapons = [];
        document.querySelectorAll('.compare-checkbox:checked').forEach(cb => {
            cb.checked = false;
        });
        updateCompareBar();
    }

    // Create comparison modal
    function createModal() {
        compareModal = document.createElement('div');
        compareModal.className = 'compare-modal';
        compareModal.innerHTML = `
            <div class="compare-modal-overlay"></div>
            <div class="compare-modal-content">
                <button class="modal-close">&times;</button>
                <h2 class="modal-title">Weapon Comparison</h2>
                <div class="comparison-table-container"></div>
            </div>
        `;
        document.body.appendChild(compareModal);

        // Close button
        compareModal.querySelector('.modal-close').addEventListener('click', hideComparison);
        compareModal.querySelector('.compare-modal-overlay').addEventListener('click', hideComparison);
    }

    // Show comparison modal
    function showComparison() {
        if (selectedWeapons.length < 2) return;

        const container = compareModal.querySelector('.comparison-table-container');
        container.innerHTML = generateComparisonTable();
        
        compareModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    // Hide comparison modal
    function hideComparison() {
        compareModal.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Generate comparison table HTML
    function generateComparisonTable() {
        const weapons = selectedWeapons.map(w => weaponDatabase[w.id]).filter(Boolean);
        
        if (weapons.length === 0) return '<p>No weapons selected</p>';

        const maxDamage = Math.max(...weapons.map(w => w.damage));
        const maxFireRate = Math.max(...weapons.map(w => w.fireRate));
        const maxRange = Math.max(...weapons.map(w => w.range));

        return `
            <div class="comparison-scroll-wrapper">
                <table class="comparison-detail-table">
                    <thead>
                        <tr>
                            <th>Stat</th>
                            ${weapons.map(w => `
                                <th class="weapon-col ${w.rarity}">
                                    <div class="weapon-col-header">
                                        <span class="col-rarity">${w.rarity}</span>
                                        <span class="col-name">${w.name}</span>
                                        <span class="col-category">${w.category}</span>
                                    </div>
                                </th>
                            `).join('')}
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="stat-label">Damage</td>
                            ${weapons.map(w => `
                                <td class="stat-cell ${w.damage === maxDamage ? 'highest' : ''}">
                                    <div class="stat-bar-container">
                                        <div class="stat-bar-fill" style="width: ${(w.damage / 100) * 100}%"></div>
                                        <span class="stat-value">${w.damage}</span>
                                    </div>
                                </td>
                            `).join('')}
                        </tr>
                        <tr>
                            <td class="stat-label">Fire Rate</td>
                            ${weapons.map(w => `
                                <td class="stat-cell ${w.fireRate === maxFireRate ? 'highest' : ''}">
                                    <div class="stat-bar-container">
                                        <div class="stat-bar-fill" style="width: ${(w.fireRate / 70) * 100}%"></div>
                                        <span class="stat-value">${w.fireRate}</span>
                                    </div>
                                </td>
                            `).join('')}
                        </tr>
                        <tr>
                            <td class="stat-label">Range</td>
                            ${weapons.map(w => `
                                <td class="stat-cell ${w.range === maxRange ? 'highest' : ''}">
                                    <div class="stat-bar-container">
                                        <div class="stat-bar-fill" style="width: ${(w.range / 100) * 100}%"></div>
                                        <span class="stat-value">${w.range}</span>
                                    </div>
                                </td>
                            `).join('')}
                        </tr>
                        <tr>
                            <td class="stat-label">Magazine</td>
                            ${weapons.map(w => `
                                <td class="text-cell">${w.magazine}</td>
                            `).join('')}
                        </tr>
                        <tr>
                            <td class="stat-label">Ammo Type</td>
                            ${weapons.map(w => `
                                <td class="text-cell">${w.ammo}</td>
                            `).join('')}
                        </tr>
                        <tr>
                            <td class="stat-label">Fire Mode</td>
                            ${weapons.map(w => `
                                <td class="text-cell">${w.mode}</td>
                            `).join('')}
                        </tr>
                        <tr>
                            <td class="stat-label">ARC Penetration</td>
                            ${weapons.map(w => `
                                <td class="text-cell penetration-${w.penetration.toLowerCase().replace(/\s+/g, '-')}">${w.penetration}</td>
                            `).join('')}
                        </tr>
                        <tr>
                            <td class="stat-label">Description</td>
                            ${weapons.map(w => `
                                <td class="desc-cell">${w.description}</td>
                            `).join('')}
                        </tr>
                    </tbody>
                </table>
            </div>
        `;
    }

    // Toast notification
    function showToast(message) {
        let toast = document.querySelector('.toast-notification');
        
        if (!toast) {
            toast = document.createElement('div');
            toast.className = 'toast-notification';
            document.body.appendChild(toast);
        }
        
        toast.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
